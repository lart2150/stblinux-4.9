#!/bin/sh
# Emulate the default login behavior while accepting the root
# user with no password
exec /bin/login -n
