#!/bin/sh
prg=`basename $0`
dir=`dirname $0`

# This script uses "git archive" to generate an stbtools tar-ball from the
# stbtools repo using a GIT SHA as version reference.

DIR_PREFIX='brcm-pm'
TARNAME='stbtools'
FORMAT='tar.gz'

if [ "$1" = "" ]; then
	echo "usage: $0 <tree-ish> (<output-path>)" 1>&2
	exit 1
fi

if [ ! -d "$dir/.git" ]; then
	echo "$prg: not a local clone of the stbtools repo" 1>&2
	exit 1
fi

# Looking up a commit like this allows us to standardize the SHA to 12
# characters and to use references such as HEAD or <SHA>~6.
sha=`git --git-dir="$dir/.git" log --abbrev=12 --format='%h' "$1" | head -1`
if [ "$sha" = "" ]; then
	exit 1
fi

if [ "$2" != "" ]; then
	output_path="$2"
else
	output_path="."
fi

prefix="$DIR_PREFIX-$sha/"
tarball="$output_path/$TARNAME-$sha.$FORMAT"

echo "Generating $tarball..."

git --git-dir="$dir/.git" archive \
	--format="$FORMAT" \
	--prefix="$prefix" \
	-o "$tarball" "$sha"

if [ $? != 0 ]; then
	rm -f "$tarball"
	exit 1
fi
