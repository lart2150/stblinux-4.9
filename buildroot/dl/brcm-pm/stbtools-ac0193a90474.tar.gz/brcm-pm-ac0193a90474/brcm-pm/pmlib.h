/*---------------------------------------------------------------------------

    Broadcom                                                     /\
    Connecting everything(R)                              _     /  \     _
    _____________________________________________________/ \   /    \   / \_
                                                            \_/      \_/

 Copyright (c) 2007-2021 Broadcom
 All rights reserved.

 Redistribution and use of this software in source and binary forms, with or
 without modification, are permitted provided that the following conditions
 are met:

 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

 * Neither the name of Broadcom Corporation nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission of Broadcom Corporation.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.

 File: pmlib.h

 Description:
 Power management library definitions

 ------------------------------------------------------------------------- */

#ifndef _H_PMLIB_
#define _H_PMLIB_

/*
 * For all read/write fields:
 *
 * BRCM_PM_UNDEF from brcm_pm_get_status() means Not Available
 * BRCM_PM_UNDEF to brcm_pm_set_status() means Don't Touch
 */

#define BRCM_PM_UNDEF			-1
#define CPUFREQ_CORE_ANY		-1
#define CPUFREQ_AVAIL_MAXLEN		128
#define CPUFREQ_GOV_MAXLEN		128
#define CPUFREQ_MAX_CORES		4

struct brcm_cpufreq {
	int base;		/* current base frequency, in kHz */
	int setspeed;		/* scaling setting, in kHz */
	char avail[CPUFREQ_AVAIL_MAXLEN];	/* available cpufreqs */
	char gov[CPUFREQ_GOV_MAXLEN];		/* current cpufreq gov. name */
};

struct brcm_pm_state {
	int sata_status;	/* 1=on, 0=off */
	int tp_status[CPUFREQ_MAX_CORES];
	struct brcm_cpufreq cpufreq[CPUFREQ_MAX_CORES];
	int srpd_status;	/* 0=no PM, >0 = timeout for self-refresh */
};

struct brcm_pm_cfg {
	int use_dhcp;		/* stop/start dhcpcd */
};

void *brcm_pm_init(void);
void brcm_pm_close(void *);

int brcm_pm_get_cfg(void *ctx, struct brcm_pm_cfg *);
int brcm_pm_set_cfg(void *ctx, struct brcm_pm_cfg *);
int brcm_pm_get_core_num(void *vctx);
void brcm_pm_set_core_num(void *vctx, int core_num);

int brcm_pm_get_tp(int tp, int *state);
int brcm_pm_set_tp(int tp, int state);
int brcm_pm_get_cur_feq(int cpu, struct brcm_cpufreq *cf);
int brcm_pm_set_cur_feq(int cpu, int freq);
int brcm_pm_get_speed(int cpu, struct brcm_cpufreq *cf);
int brcm_pm_set_speed(int cpu, struct brcm_cpufreq *cf);
int brcm_pm_get_gov(int cpu, struct brcm_cpufreq *cf, int size);
int brcm_pm_set_gov(int cpu, struct brcm_cpufreq *cf);
int brcm_pm_get_avail(int cpu, struct brcm_cpufreq *cf, int size);
int brcm_pm_set_avail(int cpu, struct brcm_cpufreq *cf);
int brcm_pm_get_status(void *vctx, struct brcm_pm_state *st);
int brcm_pm_set_status(void *vctx, struct brcm_pm_state *st);

#define BRCM_PM_STANDBY		1
#define BRCM_PM_SUSPEND		3
#define BRCM_PM_HIBERNATE	4
#define BRCM_PM_IRW_HALT	5

int brcm_pm_suspend(void *ctx, int suspend_mode);

#endif /* _H_PMLIB_ */
