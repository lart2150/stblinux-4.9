/*---------------------------------------------------------------------------

    Broadcom                                                     /\
    Connecting everything(R)                              _     /  \     _
    _____________________________________________________/ \   /    \   / \_
                                                            \_/      \_/

 Copyright (c) 2007-2021 Broadcom
 All rights reserved.

 Redistribution and use of this software in source and binary forms, with or
 without modification, are permitted provided that the following conditions
 are met:

 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

 * Neither the name of Broadcom Corporation nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission of Broadcom Corporation.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.

 File: pmtest.c

 Description:
 Power management sample application

 ------------------------------------------------------------------------- */

#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>

#include <pmlib.h>

void usage(void)
{
	int i;

	printf("usage: pmtest <cmd>\n");
	printf("\n");
	printf("examples:\n");
	printf("  status       show current power status\n");
	printf("  sata 1       power up SATA controller\n");
	printf("  tp <cpu#> 0  power down TP (secondary core)\n");
	/*
	 * We can't use CPUFREQ_MAX_CORES here, since there is only tp1-tp3. And
	 * CPUFREQ_MAX_CORES could change.
	 */
	for (i = 1; i <= 3; i++)
		printf("  tp%d 0        legacy alias; same as tp %d 0\n", i, i);
	printf("  cpu [<cpu#>] <speed> set CPU clock speed in kHz (for a core)\n");
	printf("               rounds up; will set all cores if no cpu# is given\n");
	printf("  pll 1        set alternate CPU PLL mode #1\n");
	printf("  srpd 64      enable self-refresh on all MEMCs after 64 cycles\n");
	printf("  srpd 0       disable self-refresh\n");
	printf("  standby      enter passive standby\n");
	printf("  irw_halt     enter irw_halt mode\n");
	exit(1);
}

static void warn(char *fmt, ...)
{
	va_list ap;

	fprintf(stderr, "warning: ");
	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	fputs("\n", stderr);
	fflush(stderr);
	va_end(ap);
}

static void fatal(char *fmt, ...)
{
	va_list ap;

	fprintf(stderr, "error: ");
	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	fputs("\n", stderr);
	fflush(stderr);
	va_end(ap);
	exit(1);
}

static int get_arg_as_int(const char *arg, int *has_val)
{
	char *endptr;
	long val = strtol(arg, &endptr, 0);

	*has_val = (*endptr == '\0');

	return val;
}

static int compare_val(int base, int val)
{
	if (base < val)
		return -1;
	else if (base > val)
		return 1;
	return 0;
}

static void compare_freq(int base, int val)
{
	int comp = compare_val(base, val);

	if (comp != 0) {
		warn("frequency rounded %s to %d",
			(comp < 0) ? "down" : "up", base);
	}
}

static void check_cpufreq(struct brcm_pm_state *state, int cpu_num, int val)
{
	int i;

	if (cpu_num >= 0) {
		compare_freq(state->cpufreq[cpu_num].base, val);
		return;
	}

	for (i = 0; i < CPUFREQ_MAX_CORES; i++) {
		compare_freq(state->cpufreq[i].base, val);
	}
}

int main(int argc, char **argv)
{
	struct brcm_pm_state state;
	struct brcm_pm_cfg cfg;
	void *brcm_pm_ctx;
	int val = 0, has_val = 0, ret, i, tp;
	char *cmd;
	bool legacy = false;

	while ((ret = getopt(argc, argv, "h")) != -1) {
		switch (ret) {
		case 'h':
		default:
			usage();
			break;
		}
	}

	if (optind >= argc)
		usage();
	cmd = argv[optind++];

	/* Zero out everything; not all fields may get initialized */
	memset(&state, 0, sizeof(state));

	brcm_pm_ctx = brcm_pm_init();
	if (!brcm_pm_ctx)
		fatal("can't open PM context");

	/* We need to get the current status for all cores. */
	brcm_pm_set_core_num(brcm_pm_ctx, CPUFREQ_CORE_ANY);
	if (brcm_pm_get_status(brcm_pm_ctx, &state) != 0)
		fatal("can't get PM state");

	if (brcm_pm_get_cfg(brcm_pm_ctx, &cfg) != 0)
		fatal("can't get PM config");
	if (brcm_pm_set_cfg(brcm_pm_ctx, &cfg) != 0)
		fatal("can't set PM config");

	if (!strcmp(cmd, "status")) {
		printf("sata:             %d\n", state.sata_status);
		for (i = 0; i < CPUFREQ_MAX_CORES; i++) {
			if (i != 0 || state.tp_status[i] != BRCM_PM_UNDEF) {
				printf("tp%d:              %d\n", i,
					state.tp_status[i]);
			}
		}
		for (i = 0; i < CPUFREQ_MAX_CORES; i++)
			printf("cpufreq_gov%d:      %s\n", i,
				state.cpufreq[i].gov);
		for (i = 0; i < CPUFREQ_MAX_CORES; i++) {
			if (!strcmp(state.cpufreq[i].gov, "userspace\n")) {
				printf("cpufreq_setspeed%d: %d\n", i,
					state.cpufreq[i].setspeed);
			}
		}
		for (i = 0; i < CPUFREQ_MAX_CORES; i++)
			printf("cpufreq_cur_freq%d: %d\n", i,
				state.cpufreq[i].base);
		for (i = 0; i < CPUFREQ_MAX_CORES; i++)
			printf("cpufreq_avail%d:    %s\n", i,
				state.cpufreq[i].avail);
		printf("srpd:             %d\n", state.srpd_status);
		return 0;
	}

	if (optind < argc)
		val = get_arg_as_int(argv[optind++], &has_val);

	/* second parameter is optional */

	if (!strcmp(cmd, "standby")) {
		if (has_val)
			fatal("too many arguments: PM flags are not supported");
		if (brcm_pm_suspend(brcm_pm_ctx, BRCM_PM_STANDBY) != 0)
			fatal("can't suspend");
		return 0;
	}

	if (!strcmp(cmd, "irw_halt")) {
		if (brcm_pm_suspend(brcm_pm_ctx, BRCM_PM_IRW_HALT) != 0)
			fatal("can't suspend");
		return 0;
	}

	/* second parameter is mandatory */

	if (!has_val)
		usage();

	if (!strcmp(cmd, "usb")) {
		printf("usb is no longer supported.\n");
		printf("The kernel now enables USB autosuspend by default.\n");
		return 0;
	}

	if (!strcmp(cmd, "sata")) {
		state.sata_status = val;
		if (brcm_pm_set_status(brcm_pm_ctx, &state) != 0)
			fatal("can't set PM state (SATA)");
		return 0;
	}

	if (!strcmp(cmd, "tp1") || !strcmp(cmd, "tp2") || !strcmp(cmd, "tp3")) {
		legacy = true;
		/* Turn the last character into the core number. */
		tp = cmd[2] - '0';
		/* Turn the "tpX" command into a "tp" command. */
		cmd[2] = '\0';
	}

	if (!strcmp(cmd, "tp")) {
		if (!legacy) {
			if (optind >= argc)
				fatal("command tp requires 2 arguments");
			tp = val;
			val = get_arg_as_int(argv[optind++], &has_val);
		}
		if (!has_val)
			fatal("the second argument must be numeric");
		if (brcm_pm_set_tp(tp, val) != 0)
			fatal("can't set PM state (TP%d) -- %s", tp,
				strerror(errno));
		return 0;
	}

	if (!strcmp(cmd, "srpd")) {
		state.srpd_status = val;
		if (brcm_pm_set_status(brcm_pm_ctx, &state) != 0)
			fatal("can't set PM state (SRPD)");
		return 0;
	}

	if (!strcmp(cmd, "cpu")) {
		int cpu_num = CPUFREQ_CORE_ANY;

		if (optind < argc) {
			cpu_num = val;
			val = get_arg_as_int(argv[optind++], &has_val);
		}
		if (!has_val)
			fatal("the second argument must be numeric");
		if (cpu_num == CPUFREQ_CORE_ANY) {
			int i;
			for (i = 0; i < CPUFREQ_MAX_CORES; i++) {
				strcpy(state.cpufreq[i].gov, "userspace\n");
				state.cpufreq[i].setspeed = val;
			}
		} else {
			strcpy(state.cpufreq[cpu_num].gov, "userspace\n");
			state.cpufreq[cpu_num].setspeed = val;
		}
		brcm_pm_set_core_num(brcm_pm_ctx, cpu_num);
		if (brcm_pm_set_status(brcm_pm_ctx, &state) != 0)
			fatal("can't set PM state (CPU)");
		if (brcm_pm_get_status(brcm_pm_ctx, &state) != 0)
			fatal("can't get PM state (CPU)");
		/*
		 * CPUFreq understands requests to mean minimum speed required,
		 * so it will round up when a number is not in the list unless
		 * the requested frequency exceeds scaling_max_freq
		 */
		check_cpufreq(&state, cpu_num, val);
		return 0;
	}

	usage();
	return 1;		/* never reached */
}
